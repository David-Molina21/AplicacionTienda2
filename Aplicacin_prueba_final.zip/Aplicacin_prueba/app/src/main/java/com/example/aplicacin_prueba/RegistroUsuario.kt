package com.example.aplicacin_prueba

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.aplicacin_prueba.databinding.ActivityRegistroUsuarioBinding

class RegistroUsuario : AppCompatActivity() {

    private lateinit var binding: ActivityRegistroUsuarioBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegistroUsuarioBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Aquí puedes implementar la lógica de registro
    }
}