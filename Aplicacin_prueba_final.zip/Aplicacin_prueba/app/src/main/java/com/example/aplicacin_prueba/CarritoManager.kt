package com.example.aplicacin_prueba

object CarritoManager {

    private val carrito = mutableListOf<Productos.Producto>()

    fun agregarProducto(producto: Productos.Producto) {
        carrito.add(producto)
    }

    fun obtenerCarrito(): List<Productos.Producto> {
        return carrito
    }

    fun limpiarCarrito() {
        carrito.clear()
    }
}
