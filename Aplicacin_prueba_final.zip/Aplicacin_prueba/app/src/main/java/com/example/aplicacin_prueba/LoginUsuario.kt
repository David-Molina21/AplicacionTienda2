package com.example.aplicacin_prueba

import android.app.ProgressDialog
import android.content.Intent
import android.os.Bundle
import android.util.Patterns
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.aplicacin_prueba.databinding.ActivityLoginUsuarioBinding

class LoginUsuario : AppCompatActivity() {

    private lateinit var binding: ActivityLoginUsuarioBinding
    private lateinit var progressDialog: ProgressDialog

    private var email: String = ""
    private var password: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginUsuarioBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // PROGRESSDIALOG
        progressDialog = ProgressDialog(this)
        progressDialog.setTitle("Validando")
        progressDialog.setCanceledOnTouchOutside(false)

        // 🔹 BOTÓN "¿NO TIENES CUENTA? REGISTRARSE"
        binding.todoRegistroUsuario.setOnClickListener {
            startActivity(Intent(this, RegistroActivity::class.java))
        }

        // 🔹 BOTÓN LOGIN
        binding.btnLoginC.setOnClickListener {
            validarDatos()
        }
    }

    private fun validarDatos() {
        email = binding.correoLogin.text.toString().trim()
        password = binding.contraLogin.text.toString().trim()

        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            Toast.makeText(this, "Correo inválido", Toast.LENGTH_SHORT).show()
            return
        }

        if (password.isEmpty()) {
            Toast.makeText(this, "Ingrese la contraseña", Toast.LENGTH_SHORT).show()
            return
        }

        loginUsuario()
    }

    private fun loginUsuario() {
        progressDialog.setMessage("Comprobando credenciales...")
        progressDialog.show()

        val db = DatabaseHelper(this)

        // ✔ LOGIN REAL (DatabaseHelper.verificarUsuario)
        val existe = db.verificarUsuario(email, password)

        progressDialog.dismiss()

        if (existe) {
            // ✔ Obtener usuario para mostrar su nombre
            val usuario = db.obtenerUsuario(email)

            val intent = Intent(this, MainActivityUsuario::class.java)
            intent.putExtra("usuario_id", usuario?.id ?: -1)
            startActivity(intent)
            finish()

            Toast.makeText(this, "Bienvenido ${usuario?.nombre}", Toast.LENGTH_LONG).show()

        } else {
            Toast.makeText(this, "Correo o contraseña incorrectos", Toast.LENGTH_LONG).show()
        }
    }
}
