package com.example.aplicacin_prueba

import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.aplicacin_prueba.databinding.ActivityItemProductoBinding

class ProductosAdapter(
    private val productos: List<Productos.Producto>,
    private val onAgregarClick: (Productos.Producto) -> Unit
) : RecyclerView.Adapter<ProductosAdapter.ProductoViewHolder>() {

    inner class ProductoViewHolder(val binding: ActivityItemProductoBinding)
        : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ProductoViewHolder {
        val binding = ActivityItemProductoBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return ProductoViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ProductoViewHolder, position: Int) {
        val item = productos[position]

        with(holder.binding) {
            // Asignar datos del producto
            imgProducto.setImageResource(item.imagenResId)
            tvNombre.text = item.nombre
            tvPrecio.text = item.precio

            // Abrir Item_Producto al hacer clic en el item
            holder.itemView.setOnClickListener {
                val context = holder.itemView.context
                val intent = Intent(context, Item_Producto::class.java)

                intent.putExtra("nombre", item.nombre)
                intent.putExtra("precio", item.precio)
                intent.putExtra("imagen", item.imagenResId)

                context.startActivity(intent)
            }

            // Botón "Agregar al carrito"
            btnAgregarCarrito.setOnClickListener {
                onAgregarClick(item)
            }
        }
    }

    override fun getItemCount(): Int = productos.size
}
