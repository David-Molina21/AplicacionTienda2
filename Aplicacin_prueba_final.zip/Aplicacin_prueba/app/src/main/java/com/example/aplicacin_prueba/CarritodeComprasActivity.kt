package com.example.aplicacin_prueba

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.aplicacin_prueba.databinding.ActivityCarritodeComprasBinding

class CarritodeComprasActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCarritodeComprasBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCarritodeComprasBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.tvResumen.text = "Tu carrito está vacío por ahora."
    }
}