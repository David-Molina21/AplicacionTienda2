package com.example.aplicacin_prueba

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.aplicacin_prueba.databinding.ActivityItemCarritoBinding
import com.example.aplicacin_prueba.Productos

class CarritoAdapter(
    private val items: List<Productos.Producto>
) : RecyclerView.Adapter<CarritoAdapter.ViewHolder>() {

    inner class ViewHolder(val binding: ActivityItemCarritoBinding)
        : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ActivityItemCarritoBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val producto = items[position]
        with(holder.binding) {

            imgProductoCarrito.setImageResource(producto.imagenResId)
            nombreProductoCarrito.text = producto.nombre
            precioProductoCarrito.text = producto.precio
        }
    }

    override fun getItemCount(): Int = items.size
}
