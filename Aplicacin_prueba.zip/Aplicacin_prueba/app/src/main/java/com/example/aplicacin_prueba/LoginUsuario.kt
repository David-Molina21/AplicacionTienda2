package com.example.aplicacin_prueba

import android.app.ProgressDialog
import android.content.Intent
import android.os.Bundle
import android.util.Patterns
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.aplicacin_prueba.databinding.ActivityLoginUsuarioBinding

class LoginUsuario : AppCompatActivity() {

    private lateinit var binding: ActivityLoginUsuarioBinding
    private lateinit var progressDialog: ProgressDialog

    private lateinit var email: String
    private lateinit var password: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginUsuarioBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Configurar ProgressDialog
        progressDialog = ProgressDialog(this)
        progressDialog.setTitle("Espere por favor")
        progressDialog.setCanceledOnTouchOutside(false)

        // Botón de login
        binding.btnLoginC.setOnClickListener {
            validarInfo()
        }

        // Ir al registro
        binding.todoRegistroUsuario.setOnClickListener {
            startActivity(Intent(this, RegistroUsuario::class.java))
        }
    }

    private fun validarInfo() {

        // Obtener valores reales de los EditText
        email = binding.correoLogin.text.toString().trim()
        password = binding.contraLogin.text.toString().trim()

        // Validaciones básicas
        if (email.isEmpty()) {
            binding.correoLogin.error = "Ingrese su correo"
            return
        }
        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            binding.correoLogin.error = "Correo inválido"
            return
        }
        if (password.isEmpty()) {
            binding.contraLogin.error = "Ingrese su contraseña"
            return
        }

        // Login admin local
        if (email == "admin@correo.com" && password == "1234") {
            Toast.makeText(this, "Bienvenido administrador", Toast.LENGTH_SHORT).show()
            val intent = Intent(this, ListadoProductosActivity::class.java)
            intent.putExtra("usuario", email)
            startActivity(intent)
            finish()
            return
        }

        // Si no es admin → login cliente
        loginCliente()
    }

    private fun loginCliente() {

        // Aquí pronto se agregará SQLite o API local
        progressDialog.setMessage("Ingresando...")
        progressDialog.show()

        // Simulación de validación mientras agregamos SQLite después
        progressDialog.dismiss()

        if (email == "cliente@correo.com" && password == "1234") {
            startActivity(Intent(this, MainActivityUsuario::class.java))
            finishAffinity()
            Toast.makeText(this, "Bienvenido cliente", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "Credenciales incorrectas", Toast.LENGTH_LONG).show()
        }
    }
}
