package com.example.aplicacin_prueba

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.aplicacin_prueba.databinding.ActivityProductosBinding

class Productos : AppCompatActivity() {

    private lateinit var binding: ActivityProductosBinding


    data class Producto(
        val nombre: String,
        val precio: String,
        val imagenResId: Int
    ){
        fun precioNumerico(): Int {
            return  precio.replace("$", "")
                .replace(".", "")
                .trim()
                .toInt()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        enableEdgeToEdge()

        // ✔ Inicializas el binding
        binding = ActivityProductosBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // ✔ Ajuste de insets
        ViewCompat.setOnApplyWindowInsetsListener(binding.main) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // ✔ Usas el ID del ImageView desde el binding
        binding.ivProducto.setImageResource(R.drawable.bc_ruta)
    }
}
