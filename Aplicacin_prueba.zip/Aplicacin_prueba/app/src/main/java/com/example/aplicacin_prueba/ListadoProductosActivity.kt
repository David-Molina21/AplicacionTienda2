package com.example.aplicacin_prueba

import android.content.Intent
import android.os.Bundle
import android.widget.Toast // Importa Toast para mostrar un mensaje
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.aplicacin_prueba.databinding.ActivityListadoProductosBinding

class ListadoProductosActivity : AppCompatActivity() {

    private lateinit var binding: ActivityListadoProductosBinding
    private val productos = listOf(
        Productos.Producto("Bicicleta Montañera", "$1.200.000", R.drawable.bc_montana),
        Productos.Producto("Bicicleta Ruta", "$1.350.000", R.drawable.bc_ruta),
        Productos.Producto("Bicicleta Infantil", "$600.000", R.drawable.bc_infantil),
        Productos.Producto("Bicicleta Eléctrica", "$2.500.000", R.drawable.bc_electrica)
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityListadoProductosBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.recyclerProductos.layoutManager = LinearLayoutManager(this)


        // Pasa una función lambda como segundo argumento para el parámetro 'onAgregarClick'.
        binding.recyclerProductos.adapter = ProductosAdapter(productos) { producto ->
            // Aquí defines la lógica que se ejecutará al hacer clic en "Agregar".
            // Por ejemplo, puedes mostrar un mensaje Toast.
            Toast.makeText(this, "${producto.nombre} agregado al carrito", Toast.LENGTH_SHORT).show()

            // Más adelante, aquí podrías agregar la lógica para añadir el producto
            // a una lista que represente el carrito de compras.
        }
        // --- FIN DE LA CORRECCIÓN ---

        binding.btnVerCarrito.setOnClickListener {
            startActivity(Intent(this, CarritodeComprasActivity::class.java))
        }
    }
}
