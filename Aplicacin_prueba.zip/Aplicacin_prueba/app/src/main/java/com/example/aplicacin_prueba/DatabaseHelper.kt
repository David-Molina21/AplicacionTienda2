package com.example.aplicacin_prueba

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DatabaseHelper(context: Context) :
    SQLiteOpenHelper(context, "miBD.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {

        // Tabla USUARIOS
        val createTableUsuarios = """
            CREATE TABLE usuarios(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nombre TEXT NOT NULL,
                email TEXT NOT NULL UNIQUE,
                password TEXT NOT NULL
            );
        """.trimIndent()

        db.execSQL(createTableUsuarios)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS usuarios")
        onCreate(db)
    }

    // --------------------------------------------------------------------
    // ✔ CREATE - Insertar Usuario
    // --------------------------------------------------------------------
    fun insertarUsuario(nombre: String, email: String, password: String): Boolean {
        val db = writableDatabase
        val values = ContentValues().apply {
            put("nombre", nombre)
            put("email", email)
            put("password", password)
        }

        val resultado = db.insert("usuarios", null, values)
        db.close()

        return resultado != -1L
    }

    // --------------------------------------------------------------------
    // ✔ READ - Verificar login
    // --------------------------------------------------------------------
    fun verificarUsuario(email: String, password: String): Boolean {
        val db = readableDatabase
        val cursor = db.rawQuery(
            "SELECT * FROM usuarios WHERE email=? AND password=?",
            arrayOf(email, password)
        )

        val existe = cursor.count > 0
        cursor.close()
        db.close()

        return existe
    }

    // --------------------------------------------------------------------
    // ✔ READ - Obtener usuario por email
    // --------------------------------------------------------------------
    fun obtenerUsuario(email: String): Usuario? {
        val db = readableDatabase
        val cursor = db.rawQuery(
            "SELECT * FROM usuarios WHERE email=?",
            arrayOf(email)
        )

        return if (cursor.moveToFirst()) {
            val usuario = Usuario(
                cursor.getInt(0),    // id
                cursor.getString(1), // nombre
                cursor.getString(2), // email
                cursor.getString(3)  // password
            )
            cursor.close()
            db.close()
            usuario
        } else {
            cursor.close()
            db.close()
            null
        }
    }

    // --------------------------------------------------------------------
    // ✔ UPDATE - Actualizar usuario
    // --------------------------------------------------------------------
    fun actualizarUsuario(id: Int, nombre: String, email: String, password: String): Boolean {
        val db = writableDatabase
        val values = ContentValues().apply {
            put("nombre", nombre)
            put("email", email)
            put("password", password)
        }

        val filas = db.update(
            "usuarios",
            values,
            "id=?",
            arrayOf(id.toString())
        )

        db.close()
        return filas > 0
    }

    // --------------------------------------------------------------------
    // ✔ DELETE - Eliminar usuario
    // --------------------------------------------------------------------
    fun eliminarUsuario(id: Int): Boolean {
        val db = writableDatabase
        val filas = db.delete("usuarios", "id=?", arrayOf(id.toString()))
        db.close()
        return filas > 0
    }

    // Modelo de datos
    data class Usuario(
        val id: Int,
        val nombre: String,
        val email: String,
        val password: String
    )
}
