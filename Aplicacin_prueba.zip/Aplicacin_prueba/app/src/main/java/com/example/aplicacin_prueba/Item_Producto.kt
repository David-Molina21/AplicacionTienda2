package com.example.aplicacin_prueba

import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class Item_Producto : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_item_producto)

        // Referencias del layout
        val imgProducto = findViewById<ImageView>(R.id.imgProducto)
        val tvNombre = findViewById<TextView>(R.id.tvNombre)
        val tvPrecio = findViewById<TextView>(R.id.tvPrecio)
        val btnAgregarCarrito = findViewById<Button>(R.id.btnAgregarCarrito)

        // Recibir datos del Adapter
        val nombre = intent.getStringExtra("nombre")
        val precio = intent.getStringExtra("precio")
        val imagen = intent.getIntExtra("imagen", 0)

        // Asignar valores a las vistas
        tvNombre.text = nombre ?: "Nombre no disponible"
        tvPrecio.text = precio ?: "Precio no disponible"

        if (imagen != 0) {
            imgProducto.setImageResource(imagen)
        }

        // Acciones
        btnAgregarCarrito.setOnClickListener {
            // Aquí luego podemos agregar funcionalidad
        }
    }
}
