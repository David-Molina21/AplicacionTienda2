package com.example.aplicacin_prueba

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.aplicacin_prueba.databinding.ActivityMainUsuarioBinding

class MainActivityUsuario : AppCompatActivity() {

    private var _binding: ActivityMainUsuarioBinding? = null
    // uso safeBinding para evitar NPEs en onDestroy
    private val binding get() = _binding!!

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Intentamos usar ViewBinding (si está configurado)
        try {
            _binding = ActivityMainUsuarioBinding.inflate(layoutInflater)
            setContentView(binding.root)
        } catch (e: Exception) {
            // Si falla el inflate porque no está habilitado binding o layout diferente,
            // hacemos un fallback simple (exponemos info en log)
            Log.w("MainActivityUsuario", "ViewBinding falló: ${e.message}. Se intentará fallback con setContentView(layout).")
            setContentView(R.layout.activity_main_usuario) // Asegúrate que exista este layout
        }

        // 1) Intentamos asignar listener usando binding (si binding fue inicializado correctamente)
        var listenerAssigned = false
        try {
            // Verificamos que el botón exista en el binding
            val btn = binding.root.findViewById<Button?>(R.id.btnIrLogin)
            if (btn != null) {
                btn.setOnClickListener {
                    abrirLogin()
                }
                listenerAssigned = true
            }
        } catch (e: UninitializedPropertyAccessException) {
            // binding no inicializado: simplemente lo ignoramos y seguimos al fallback
        } catch (e: Exception) {
            Log.w("MainActivityUsuario", "Error verificando binding: ${e.message}")
        }

        // 2) Si no logramos con binding, intentamos findViewById directamente (fallback)
        if (!listenerAssigned) {
            val btnFallback = findViewById<Button?>(R.id.btnIrLogin)
            if (btnFallback != null) {
                btnFallback.setOnClickListener {
                    abrirLogin()
                }
                listenerAssigned = true
            }
        }

        // 3) Si aún no se asignó, damos feedback en log y en pantalla
        if (!listenerAssigned) {
            Log.e("MainActivityUsuario", "No se encontró btnIrLogin en el layout. Verifica el id y que uses R.layout.activity_main_usuario.")
            Toast.makeText(this, "Botón de Login no encontrado (btnIrLogin). Revisa layout.", Toast.LENGTH_LONG).show()
        }
    }

    private fun abrirLogin() {
        val intent = Intent(this, LoginActivity::class.java)
        startActivity(intent)
    }

    override fun onDestroy() {
        super.onDestroy()
        // evitar fugas de memoria
        _binding = null
    }
}
